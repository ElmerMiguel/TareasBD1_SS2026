# Comparación de Consultas: TypeORM QueryBuilder vs SQL Manual

## Ejercicio #10B — Consulta con JOIN, Parámetro y Ordenamiento

En este ejercicio se implementó una consulta personalizada para obtener los libros que pertenecen a una categoría específica (ejemplo: `"Novela"`), ordenados alfabéticamente por título.

---

### 1. Código TypeScript con QueryBuilder en NestJS

```typescript
async findByCategoria(categoria: string): Promise<Libro[]> {
  return await this.repo
    .createQueryBuilder('l')
    .innerJoinAndSelect('l.categoria', 'c')
    .where('c.nombre = :nombre', { nombre: categoria })
    .orderBy('l.titulo', 'ASC')
    .getMany();
}
```

---

### 2. Tabla Comparativa Lado a Lado

| Aspecto | SQL Generado por TypeORM (Log Oficial) | SQL Equivalente Escrito a Mano |
| :--- | :--- | :--- |
| **Sentencia SQL** | `SELECT "l"."id" AS "l_id", "l"."titulo" AS "l_titulo", "l"."precio" AS "l_precio", "l"."disponible" AS "l_disponible", "l"."existencias" AS "l_existencias", "l"."idautor" AS "l_idautor", "l"."categoria_id" AS "l_categoria_id", "c"."id" AS "c_id", "c"."nombre" AS "c_nombre" FROM "libro" "l" INNER JOIN "categoria" "c" ON "c"."id"="l"."categoria_id" WHERE "c"."nombre" = $1 ORDER BY "l"."titulo" ASC` | `SELECT l.id, l.titulo, l.precio, l.disponible, l.existencias, l.idautor, l.categoria_id, c.id AS categoria_id, c.nombre AS categoria_nombre FROM libro l INNER JOIN categoria c ON c.id = l.categoria_id WHERE c.nombre = 'Novela' ORDER BY l.titulo ASC;` |
| **Parámetros** | `-- PARAMETERS: ["Novela"]` (Parametrizada mediante `$1`) | Valor literal incrustado o marcador posicional `$1` en prepared statement |
| **Alias de Columnas** | TypeORM califica y renombra cada columna (`"l"."id" AS "l_id"`, `"c"."nombre" AS "c_nombre"`) con comillas dobles para evitar ambigüedades e hidratar las entidades TypeScript anidadas. | Se eligen alias legibles según la necesidad de la vista o reporte. |
| **Seguridad** | **Protegido contra inyección SQL**: el valor nunca se concatena en el texto de la consulta, sino que se transmite al driver de PostgreSQL como parámetro binario separado. | Si se construye con concatenación manual de cadenas en backend sin prepared statements, es altamente vulnerable a inyecciones SQL. |

---

### 3. Log Exacto Capturado de la Consola del Servidor

```text
query: SELECT "l"."id" AS "l_id", "l"."titulo" AS "l_titulo", "l"."precio" AS "l_precio", "l"."disponible" AS "l_disponible", "l"."existencias" AS "l_existencias", "l"."idautor" AS "l_idautor", "l"."categoria_id" AS "l_categoria_id", "c"."id" AS "c_id", "c"."nombre" AS "c_nombre" FROM "libro" "l" INNER JOIN "categoria" "c" ON "c"."id"="l"."categoria_id" WHERE "c"."nombre" = $1 ORDER BY "l"."titulo" ASC -- PARAMETERS: ["Novela"]
```

---

### 4. Análisis Técnico de la Consulta

1. **Hidratación de Objetos:** TypeORM genera alias con prefijo de entidad (`l_` y `c_`) para reconstruir la estructura de árbol en TypeScript: el objeto `Libro` contiene internamente el objeto `categoria: { id: 1, nombre: 'Novela' }`.
2. **Parametrización Automática:** A diferencia de una consulta SQL concatenada (`WHERE c.nombre = '` + cat + `'`), TypeORM delega la interpolación al protocolo nativo de PostgreSQL mediante marcadores de posición posicionales (`$1`, `$2`), previniendo cualquier vector de inyección SQL (SQL Injection).
3. **Optimización con Índices:** Al filtrar sobre `c.nombre` y ordenar sobre `l.titulo`, el planificador de consultas de PostgreSQL (Planner) aprovecha los índices existentes sobre la llave foránea `categoria_id` y las llaves primarias para resolver la combinación eficientemente.
