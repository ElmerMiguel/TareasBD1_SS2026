import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { LibrosService } from './libros.service.js';
import { LibrosController } from './libros.controller.js';
import { Libro } from '../entidades/libro.entity.js';
import { Autor } from '../entidades/autor.entity.js';
import { Categoria } from '../entidades/categoria.entity.js';
import { Prestamo } from '../entidades/prestamo.entity.js';

@Module({
  imports: [TypeOrmModule.forFeature([Libro, Autor, Categoria, Prestamo])],
  controllers: [LibrosController],
  providers: [LibrosService],
  exports: [LibrosService],
})
export class LibrosModule {}
