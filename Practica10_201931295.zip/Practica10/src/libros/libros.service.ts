import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Libro } from '../entidades/libro.entity.js';
import { Prestamo } from '../entidades/prestamo.entity.js';
import { CreateLibroDto } from './dto/create-libro.dto.js';
import { UpdateLibroDto } from './dto/update-libro.dto.js';

@Injectable()
export class LibrosService {
  constructor(
    @InjectRepository(Libro)
    private readonly repo: Repository<Libro>,
    private readonly dataSource: DataSource,
  ) {}

  async create(dto: CreateLibroDto): Promise<Libro> {
    const libro = this.repo.create({
      titulo: dto.titulo,
      precio: dto.precio,
      disponible: dto.disponible ?? true,
      existencias: dto.existencias ?? 5,
      ...(dto.idautor ? { autor: { id: dto.idautor } as any } : {}),
      ...(dto.categoria_id ? { categoria: { id: dto.categoria_id } as any } : {}),
    });
    return await this.repo.save(libro);
  }

  async findAll(): Promise<Libro[]> {
    return await this.repo.find();
  }

  async findAllWithRelations(): Promise<Libro[]> {
    return await this.repo.find({
      relations: {
        categoria: true,
        autor: true,
      },
    });
  }

  async findByCategoria(categoria: string): Promise<Libro[]> {
    return await this.repo
      .createQueryBuilder('l')
      .innerJoinAndSelect('l.categoria', 'c')
      .where('c.nombre = :nombre', { nombre: categoria })
      .orderBy('l.titulo', 'ASC')
      .getMany();
  }

  async findOne(id: number): Promise<Libro> {
    const libro = await this.repo.findOneBy({ id });
    if (!libro) {
      throw new NotFoundException(`Libro con id ${id} no encontrado`);
    }
    return libro;
  }

  async update(id: number, dto: UpdateLibroDto): Promise<Libro> {
    const libro = await this.findOne(id);
    if (dto.titulo !== undefined) libro.titulo = dto.titulo;
    if (dto.precio !== undefined) libro.precio = dto.precio;
    if (dto.disponible !== undefined) libro.disponible = dto.disponible;
    if (dto.existencias !== undefined) libro.existencias = dto.existencias;
    if (dto.idautor !== undefined) (libro as any).autor = { id: dto.idautor };
    if (dto.categoria_id !== undefined) (libro as any).categoria = { id: dto.categoria_id };
    return await this.repo.save(libro);
  }

  async remove(id: number): Promise<{ message: string; id: number }> {
    const result = await this.repo.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`Libro con id ${id} no encontrado`);
    }
    return { message: 'Libro eliminado con éxito', id };
  }

  async prestar(id: number) {
    return await this.dataSource.transaction(async (manager) => {
      const libro = await manager.findOneBy(Libro, { id });
      if (!libro) {
        throw new NotFoundException(`Libro con id ${id} no encontrado`);
      }

      // 1. Guardar préstamo
      const prestamo = manager.create(Prestamo, {
        libro: { id } as any,
        idlibro: id,
        dias: 5,
        fecha: new Date().toISOString().split('T')[0],
      });
      await manager.save(Prestamo, prestamo);

      // 2. Decrementar existencias
      await manager.decrement(Libro, { id }, 'existencias', 1);

      return {
        message: 'Préstamo registrado con éxito dentro de la transacción',
        prestamoId: prestamo.id,
        libroId: id,
      };
    });
  }
}
