export class UpdateLibroDto {
  titulo?: string;
  precio?: number;
  disponible?: boolean;
  existencias?: number;
  idautor?: number;
  categoria_id?: number;
}
