import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import type { Relation } from 'typeorm';
import { Libro } from './libro.entity.js';

@Entity('categoria')
export class Categoria {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100, unique: true })
  nombre: string;

  @OneToMany(() => Libro, (libro) => libro.categoria)
  libros: Relation<Libro[]>;
}
