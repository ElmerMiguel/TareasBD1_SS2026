import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import type { Relation } from 'typeorm';
import { Autor } from './autor.entity.js';
import { Categoria } from './categoria.entity.js';
import { Prestamo } from './prestamo.entity.js';

@Entity('libro')
export class Libro {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 150 })
  titulo: string;

  @Column('numeric', { precision: 10, scale: 2, nullable: true })
  precio: number;

  @Column({ default: true })
  disponible: boolean;

  @Column({ default: 5 })
  existencias: number;

  @ManyToOne(() => Autor, (a) => a.libros, { nullable: true })
  @JoinColumn({ name: 'idautor' })
  autor: Relation<Autor>;

  @ManyToOne(() => Categoria, (c) => c.libros, { nullable: true })
  @JoinColumn({ name: 'categoria_id' })
  categoria: Relation<Categoria>;

  @OneToMany(() => Prestamo, (p) => p.libro)
  prestamos: Relation<Prestamo[]>;
}
