import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import type { Relation } from 'typeorm';
import { Libro } from './libro.entity.js';

@Entity('prestamo')
export class Prestamo {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  idsocio: number;

  @Column({ nullable: true })
  idlibro: number;

  @Column({ nullable: true })
  dias: number;

  @Column({ type: 'date', default: () => 'CURRENT_DATE' })
  fecha: string;

  @ManyToOne(() => Libro, (l) => l.prestamos, { nullable: true, onDelete: 'CASCADE' })
  @JoinColumn({ name: 'libro_id' })
  libro: Relation<Libro>;
}
