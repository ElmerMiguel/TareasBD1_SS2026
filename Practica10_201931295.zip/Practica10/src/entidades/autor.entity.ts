import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import type { Relation } from 'typeorm';
import { Libro } from './libro.entity.js';

@Entity('autor')
export class Autor {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100, unique: true })
  nombre: string;

  @Column({ length: 50, nullable: true })
  nacionalidad: string;

  @OneToMany(() => Libro, (libro) => libro.autor)
  libros: Relation<Libro[]>;
}
