import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller.js';
import { AppService } from './app.service.js';
import { LibrosModule } from './libros/libros.module.js';
import { Autor } from './entidades/autor.entity.js';
import { Categoria } from './entidades/categoria.entity.js';
import { Libro } from './entidades/libro.entity.js';
import { Prestamo } from './entidades/prestamo.entity.js';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST ?? 'localhost',
      port: Number(process.env.DB_PORT ?? 5432),
      username: process.env.DB_USER ?? 'user1',
      password: process.env.DB_PASSWORD ?? 'pos1234',
      database: process.env.DB_NAME ?? 'biblioteca',
      synchronize: false,
      logging: true,
      entities: [Autor, Categoria, Libro, Prestamo],
    }),
    LibrosModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
