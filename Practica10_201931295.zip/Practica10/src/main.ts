import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const port = process.env.PORT ?? 3095;
  await app.listen(port);
  console.log(`\n🚀 Servidor NestJS + TypeORM ejecutándose en: http://localhost:${port}\n`);
}
await bootstrap();
